import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-success',
  templateUrl: './request-success.component.html',
  styleUrls: ['./request-success.component.scss']
})
export class RequestSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
